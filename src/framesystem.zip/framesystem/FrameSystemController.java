package framesystem;

public class FrameSystemController {

}
